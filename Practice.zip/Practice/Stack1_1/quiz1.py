stack = []

stack.append(1)  # push
stack.append(2)
stack.append(3)

print(stack.pop())  # pop
print(stack.pop())
print(stack.pop())

# size = 10
# stack = [] * 10
# top = -1
#
# if top != size-1:
#     stack.append(1)
#
# if top != -1:
#     stack.pop()


